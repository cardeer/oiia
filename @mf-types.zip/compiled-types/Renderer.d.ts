import './style.css';
import { FC } from 'react';
declare const Renderer: FC;
export default Renderer;

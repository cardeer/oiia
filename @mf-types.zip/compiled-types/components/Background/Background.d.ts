import { FC } from 'react';
declare const Background: FC;
export default Background;

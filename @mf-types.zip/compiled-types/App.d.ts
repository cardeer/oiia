export declare function bootstrap(options: any): import("react").ReactPortal | undefined;
